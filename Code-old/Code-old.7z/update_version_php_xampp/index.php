<?php 
// C:\Users\BryanLizana\AppData\Roaming\Code\User\settings.json
// C:\xampp
// C:\xampp\apache\conf\extra
// $sites = file_get_contents('sites.js');
// $sites =  json_decode( $sites, true );


if ($_SERVER['REQUEST_METHOD'] == 'POST') {

//    C:\xampp\apache\conf\extra
// httpd-vhosts.conf
// httpd-xampp.conf


if (file_exists($_REQUEST['path'])) {
    $_REQUEST['path'] = "D:\\xampp\\";
}


$path_htdocs = $_REQUEST['path']. 'htdocs\\' ;
$array_scadir_path = scandir($path_htdocs,1) ;
//found sites folders
foreach ($array_scadir_path as $path_folder) {
    if (is_dir($path_htdocs . $path_folder)  && $path_folder  != '.' &&  $path_folder != '..'   ) {
        if (  strpos($path_folder,"ww.") > 0|| strpos($path_folder,"ev.") > 0  ) {
              $sites[] =  str_replace(' ','', $path_folder);
               // echo $path_htdocs . $path_folder ;
        }

    }
}


//path vhost
 $aLineas = file($_REQUEST['path'].'apache\\conf\\extra\\httpd-vhosts.conf');


//write in file
foreach ($aLineas as $nline => $line) {
    if ( strpos($line,"##vhost###") > 0|| strpos($line,"##end-vhost###") > 0) {
        $star_end[] = $nline ;
        // echo '<pre>'; var_dump( $line ); echo '</pre>'; /***VAR_DUMP_DIE***/ 
    }
}
if (count($star_end) != 2) {
   $aLineas[] = " \n ###vhost### \n";
   $star_end[]  = count($aLineas ) - 1;

   $all_next_end_vhost[] = " \n ###end-vhost### \n";
}else {
    //save all next end-VHOST
   $all_next_end_vhost =  array_slice($aLineas,$star_end[1]);
   $aLineas  =  array_slice($aLineas,0,$star_end[0] +1 );

}
//create vhost´s

foreach ($sites as $site_) {
    $path_final = $path_htdocs .$site_ ;
    $path_final = str_replace("\\","/",$path_final);
    $aLineas[]  = '<VirtualHost *:80> ' ."\n" ;
    $aLineas[]  = ' DocumentRoot "'.$path_final.'" ' ."\n" ;
    $aLineas[]  = ' ServerName '.$site_.' ' ."\n" ;
    $aLineas[]  = ' ErrorLog "logs/error.log" ' ."\n" ;
    $aLineas[]  = ' CustomLog "logs/access.log" common ' ."\n" ;
    $aLineas[]  = '</VirtualHost> ' ."\n\n" ;

}


//end
$aLineas = array_merge($aLineas,$all_next_end_vhost);

$archivo = fopen($_REQUEST['path'].'apache\\conf\\extra\\httpd-vhosts.conf',"c+");
    // Guardar los cambios en el archivo:
     foreach( $aLineas as $linea )
         fwrite($archivo, $linea);

$archivo = fopen($_REQUEST['path'].'htdocs\\IPs.txt',"c+");
    // Guardar los cambios en el archivo:
     foreach( $sites as $site_ )
         fwrite($archivo, '
         127.0.0.1  ' . $site_ );



//Preparar las versiones de php existente

$conf = file_get_contents('conf.json');
$conf = json_decode( $conf, true );
// $conf['sites'] = json_encode( $sites ) ;
$conf['sites'] = $sites; //Update sites folders
//añadir nuevas versiones:
if ($_REQUEST['add_v_php'] != null ) {
   $conf['php_vs'][] = $_REQUEST['add_v_php'];
}

if (!in_array(phpversion(),$conf['php_vs'])) {
   $conf['php_vs'][] = phpversion();
}


//update file 
  file_put_contents('conf.json',json_encode( $conf ));


// echo '<pre>'; var_dump( $conf ); echo '</pre>'; die; /***VAR_DUMP_DIE***/ 
//$conf['php_vs'] //vars for php versions


//Changed Version PHP

// php_version
if ($_REQUEST['php_version']  != '0') {
    # code...
    $archivo = $_REQUEST['path'].'apache\\conf\\extra\\httpd-xampp.conf';
        //read the entire string
            $str=file_get_contents( $archivo );

            $php_v_old = substr(phpversion(),0,1);
            $php_version =substr($_REQUEST['php_version'],0,1);
            
            //replace something in the file string - this is a VERY simple example
            $str=str_replace($php_v_old,  $php_version,$str);
            //write the entire string
            file_put_contents( $archivo, $str);
                   
}



echo '<h1>Listo¡¡¡ Recarga Xampp</h1>';

//rename folders
// START  D:\xampp\apache\conf\extra/
// START C:\Windows\System32\drivers\etc
if ( $_REQUEST['php_version'] != 0) {
    echo "START ". $_REQUEST['path']."\apache\conf\\extra/". " <br> ";
echo "START C:\Windows\System32\drivers\\etc". " <br> ";
echo "cd ".$_REQUEST['path']. " <br> ";

 echo  "rename php php". phpversion() . " <br> ";
 echo  "rename php". $_REQUEST['php_version']." php". " <br> ";
 echo "ECHO FIN";
}
}
 ?>
 <!DOCTYPE html>
 <html lang="en">
     <head>
         <title></title>
         <meta charset="UTF-8">
         <meta name="viewport" content="width=device-width, initial-scale=1">
         <link href="css/style.css" rel="stylesheet">
     </head>
     <body>
        <h3>Ingresa Path de Xampp</h3>
        <form method="POST" >
           <input type="text" name="path" value="<?php echo $path_xampp = (isset($_REQUEST['path'])) ? $_REQUEST['path'] : 'C:\xampp\\' ; ?>" placeholder="Path of Xampp/">

            <!--<select   name="path" style="
                margin: 10px;
                padding: 10px;
            ">
      
                         <option value="C:\xampp\\" >C:\xampp\\</option>
                         <option value="D:\xampp\\" >D:\xampp\\</option>           
                
            </select>-->
         <br>
         <hr>
         <span>Asegurarse que tengas el folder para php (win32-vc14-x86   no 'nts' )  => <a href="http://windows.php.net/downloads/releases/">Versions</a></span>
         <p>La version que deseas se debe preparar manualmente, el contenido de tu versión de php debe de ser movido al folder php/</p>
         <p>NO OLVIDAR COPIAR EL ARCHIVO php.ini PARA LA CONF DEL PHPv</p>
          <br>

            <?php $sites = file_get_contents('conf.json') ?>
            <?php $sites = json_decode( $sites,true ) ?>
          <!--<input type="text" name="php_v_old" value="5" placeholder="Version old (number folder) - conf anterior de php v de xammp">-->
           <!--<select name="php_v_old"> Old Version Php
                <option value="0" selected >no</option> 
                <?php //foreach ($sites['php_vs'] as $phpv ): ?>
                      <option value="<?php //echo $phpv ?>">PHP <?php //echo $phpv ?></option>                        
                <?php //endforeach ?>              
            </select>-->
             <input type="text" name="add_v_php" value="" placeholder="Add v. exp: '7.1.1'"><br>
             <br>
            <select name="php_version"> New Version Php
                <option value="0" selected >no</option>                
                <?php foreach ($sites['php_vs'] as $phpv ): ?>
                      <option value="<?php echo $phpv ?>">PHP <?php echo $phpv ?></option>                        
                <?php endforeach ?>   
            </select>
          
            <br>
            <br>
            
            <input type="submit" name="" value="Update">
        </form>
<hr>
<?php  echo phpversion() ?>


<hr>

        <table>

          <?php foreach ($sites['sites'] as $site_): ?>
                <tr><td> <a href="http://<?php echo $site_ ?>" target="_black" ><?php echo $site_ ?></a> </td></tr>
          <?php endforeach ?>
        </table>

     </body>
 </html>