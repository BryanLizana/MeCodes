<?php 
if (isset($_POST['test001']) && !empty($_POST['test001']) ) {
    
    $archivo = fopen("close_msj.json","c+");
    // Guardar los cambios en el archivo:
    //  foreach( $aLineas as $linea )
         fwrite($archivo, $_POST['test001']);
         
         die;

}
 ?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!--<link href="css/style.css" rel="stylesheet">-->
    </head>
    <body>
    <script language="JavaScript">
        window.onbeforeunload = confirmExit;
        function confirmExit()
        {

            // alert('bye');
            

            var http = new XMLHttpRequest();
            var url = "http://dev.proccess.com/close_msj.php";
            var params = "test001= <?php echo date('hh:ss')?> &name=binny";
            http.open("POST", url, true);

            //Send the proper header information along with the request
            http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

            http.onreadystatechange = function() {//Call a function when the state changes.
                // if(http.readyState == 4 && http.status == 200) {
                //     alert(http.responseText);
                // }
                console.log(http);
                
            }
            http.send(params);

            return "Ha intentado salir de esta pagina. Si ha realizado algun cambio en los campos sin hacer clic en el boton Guardar, los cambios se perderan. Seguro que desea salir de esta pagina? ";
            
            
        }
        </script>

        <script>
            // confirmExit();
        </script>
    </body>
</html>
