<footer>
    <?php  fn_asset_js(); ?> 
</footer>

</html>