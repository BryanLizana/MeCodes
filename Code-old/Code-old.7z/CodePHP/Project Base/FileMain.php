<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once('Load.php');
require_once('Functions.php');

$module = $_REQUEST['module'];
unset($_REQUEST['module']);


define('MODULE_PATH',VIEWS.$module.DIRECTORY_SEPARATOR ); //path module folder
define('MODULE_NAME',$module); // module name

//Start Page
session_start();
require_once(MODULE_PATH .'index.php');

