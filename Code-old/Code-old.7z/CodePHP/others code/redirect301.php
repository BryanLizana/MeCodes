<!DOCTYPE html>
<html>
<head>
	<title>STR Replace</title>
</head>
<body>
<form action="" method="post">
	<table>
		<tr>
			<td colspan="2">Original Url <input type="text" name="original" value="<?php echo $_POST["original"] ?>"></td>
		</tr>
		<tr>
			<td>Last Url<br>
			<textarea cols="70" rows="30" name="data"><?php echo $_POST["data"] ?></textarea>
			</td>
			<td>New Url<br>
			<textarea cols="50" rows="30" name="find"><?php echo $_POST["find"] ?></textarea>
			</td>
			<!--<td>Replace<br>
			<textarea cols="50" rows="30" name="replace"><?php echo $_POST["replace"] ?></textarea>
			</td>-->
		</tr>
	</table>
	<input type="submit" value="Enviar" name="b_enviar">
</form>

<?php
if($_POST["data"]):
	//$find=explode("\r\n",$_POST["find"]);
	?><h3>New Data</h3>
<div class="new">
<?php
	$data=explode("\r\n",$_POST["data"]);
	$find=explode("\r\n",$_POST["find"]);
	$original=$_POST["original"];
	//echo $original."<hr>";
	//$data=str_replace("\r\n", "<br>", $data);

	//redirect 301 /url_antigua.html http://www.dominio-nuevo.com/url-nueva/
	for($n=0;$n<count($data);$n++)
	{
		$ff=$find[$n];
		$dd=$data[$n];
		if($original)
		{

			$dd=str_replace($original, "", $dd);
			if(substr($dd, -1)=="/"){
				$redirect='RedirectMatch 301 ^/'.$dd.'(.*)$';
			}else{
				if (!empty($dd)) {
					$n_dd = stripos($dd,"?");
					if ($n_dd ) {
						$dd = substr($dd,0,$n_dd);
					}

					$redirect='Redirect 301 /'.$dd;
					//$dd = "/";
				}
			}
		}
?>
<?php if ($ff != "NN"): ?>
	<?php echo $redirect;
	 echo $ff; ?><br>
<?php endif; ?>

<?php
	}
?>


	<!-- <?php echo $new; ?> -->
</div>
<h3>Verificacion de URLS</h3>
<div>
<table>
<?php
for($n=0;$n<count($data);$n++)
	{
		$ff=$find[$n];
		$dd=$data[$n];
		if($original)
		{

			//$dd=str_replace($original, "", $dd);
			//if(empty($dd))
			//{
			//	$dd="/";
			//}

		}
?>
		<tr><td><a href="<?php echo $dd; ?>" target="_blank"><?php echo $dd; ?></a></td><td> <?php echo $ff; ?><br></td></tr>
<?php
	}
?>
</table>
</div>

<style type="text/css">
	.new
	{
		background-color: lightyellow;
		padding: 20px;
		border: 1px solid #000;
		margin: 20px;
	}
</style>
<?php
endif;
?>
</body>
</html>
