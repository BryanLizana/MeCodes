
<!DOCTYPE html>
<html lang="en">
    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/style.css" rel="stylesheet">
    </head>
    <body>
    <h1>Crear sp_Create</h1>
<?php 
    // functions
     function insert_txt($params_type, $params,$params_v,$table)
    {
        
          foreach ($params as  $value) {
        $txt_set[] = $value ."= @" .$value ; 
            
        }
        $txt_params = implode(',',$params);
        $txt_params_v = implode(',',$params_v);
        $txt_set_f = implode(',',$txt_set);
   
        $table= trim($table,"[");
        $table= trim($table,"]");
 
        $txt = "create procedure sp_Insert_$table (  <br>";

        // $params_type  
    
        $params_type = implode(" ,  <br> ",$params_type);
        $txt .= $params_type;
        
        $txt .= ") AS  <br>";

        $txt.= "if @".$params[0] ." = 0  <br>";
        $txt.= " begin  <br>";
        $txt.=   "INSERT INTO ".$table."( ".$txt_params." ) VALUES (".$txt_params_v.")  <br>" ;
        $txt.=  "end  <br>";
        $txt.=    "else  <br>";
        $txt.=  "begin  <br>";
        $txt.=  "UPDATE ".$table." set ".$txt_set_f."  WHERE ". $params[0] ." =  @". $params[0] ."  <br>" ;
        $txt.= "end  <br>";
        $txt.= "GO  <br>";  
        $txt.= "  <br>";  
        $txt.= " ------------------------------------- <br>";  
        
echo $txt; 

        $txt = "create procedure sp_List_$table (  <br>";
    
        $txt .= "@".$params[0] ." int ";
        
        $txt .= ") AS  <br>";

        $txt.= "if @".$params[0] ." = 0  <br>";
        $txt.= " begin  <br>";
        $txt.=   "SELECT * FROM ". $table ." <br>" ;
        $txt.=  "end  <br>";
        $txt.=    "else  <br>";
        $txt.=  "begin  <br>";
        $txt.=  "SELECT * FROM ".$table." WHERE ". $params[0] ." =  @". $params[0] ."  <br>" ;
        $txt.= "end  <br>";
        $txt.= "GO  <br>";  
      $txt.= "  <br>";  
        $txt.= " ------------------------------------- <br>";  

              
        echo $txt;

        $txt = "create procedure sp_Delete_$table (  <br>";
        $txt .= "@". $params[0] ." int ";
        $txt .= ") AS  <br>";
        $txt.=  "begin  <br>";
        $txt.=  "DELETE  ".$table." WHERE ". $params[0] ." =  @". $params[0] ."  <br>" ;
        $txt.= "end  <br>";
        $txt.= "GO  <br>";  
         $txt.= "  <br>";  
        $txt.= " ------------------------------------- <br>"; 
        
        echo $txt;

        foreach ($params as  $value) {
            $txt = " public string ".ucwords($value) ." {get;set;}  <br>";
            echo $txt;
        }

        foreach ($params as  $value) {
            $txt = 'cmd.Parameters.Add("@'.$value.'", SqlDbType.Varchar,30).Value = '.$table.'.'.ucwords($value).';<br>';echo  $txt;
        }

       

    }
  ?>
    <form action=""  method="POST" name="frm" >
        <span>No "["   ni  "]"  please</span><br>
        <textarea rows="30" cols="60" name= "txtparams"></textarea> <br>

        <!--<input type="text" name="txtn_" placeholder ="Number of txt">-->
        <input type="submit" name="btnform" value ="SubmitF1" >
        
        </form>

           <?php 
                if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_REQUEST['btnform'] = "SubmitF1") {
                 

                    $rows = explode("\n" ,$_REQUEST['txtparams'] );

                    foreach ($rows as  $value) {                        
                        if (trim($value )  != "") {
                        $paramss = explode("http://www.",$value);
                            echo "http://www.".$paramss[1] ."<br>";
                        }
                     }
                    
                                                          
                }
            ?>


    </body>
</html>


