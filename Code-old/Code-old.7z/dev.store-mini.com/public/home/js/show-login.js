
    $(window).load(function(){
        $('#login').modal('show');
    });