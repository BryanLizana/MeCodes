<?php 
namespace Models;
/**
 * 
 */
class ClassModule 
{
    
    function __construct()
    {
        # code...
    }

    public function test()
    {
        return 'test';
    }
}
