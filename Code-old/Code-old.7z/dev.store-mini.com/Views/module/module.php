<div>
Module Body
<form method="POST">
 
    <input type="submit" name="test" value="test">
</for>
</div>