<?php 
// session_start();
session_destroy();

//redirect to page actual;