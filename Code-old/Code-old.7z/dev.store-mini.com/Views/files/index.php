<?php $page_this = "FILES"; ?>

<?php 

			include(MODULE_PATH.$_REQUEST['page'].'.php');
        
