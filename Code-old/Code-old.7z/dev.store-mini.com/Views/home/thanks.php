<div id="mainBody">
	<div class="container">
	<div class="row">
<!--
    <h1>Thanks</h1>-->
    	<a href="<?php echo MODULE_PATH_WEB ?>" class="btn btn-large"><i class="icon-arrow-left"></i> Continue Shopping </a>
<br>    
    <img src="http://www.distribuidora-aluvent.com/images/gracias-compra.jpg" alt="">
    </div>
    </div>
	</div>
</div>
