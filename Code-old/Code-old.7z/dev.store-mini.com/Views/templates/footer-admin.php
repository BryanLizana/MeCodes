  <!-- Javascripts-->
    <script src="<?php echo PATH_RESOURCE ?>assets/templates/js/jquery-2.1.4.min.js"></script>
    <script src="<?php echo PATH_RESOURCE ?>assets/templates/js/essential-plugins.js"></script>
    <script src="<?php echo PATH_RESOURCE ?>assets/templates/js/bootstrap.min.js"></script>
    <script src="<?php echo PATH_RESOURCE ?>assets/templates/js/plugins/pace.min.js"></script>
    <script src="<?php echo PATH_RESOURCE ?>assets/templates/js/main.js"></script>
    <script type="text/javascript" src="<?php echo PATH_RESOURCE ?>assets/templates/js/plugins/chart.js"></script>
    <script type="text/javascript" src="<?php echo PATH_RESOURCE ?>assets/templates/js/plugins/jquery.vmap.min.js"></script>
    <script type="text/javascript" src="<?php echo PATH_RESOURCE ?>assets/templates/js/plugins/jquery.vmap.world.js"></script>
    <script type="text/javascript" src="<?php echo PATH_RESOURCE ?>assets/templates/js/plugins/jquery.vmap.sampledata.js"></script>
    <script type="text/javascript" src="<?php echo PATH_RESOURCE ?>assets/templates/js/plugins/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="<?php echo PATH_RESOURCE ?>assets/templates/js/plugins/dataTables.bootstrap.min.js"></script>
     <script type="text/javascript">$('#sampleTable').DataTable();</script>
   
  </body>
</html>