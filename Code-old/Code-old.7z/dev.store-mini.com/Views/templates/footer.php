<!-- Footer ================================================================== -->
	<div  id="footerSection">
	<div class="container">
		<div class="row">
		
			
		 </div>
		<p class="pull-right">&copy; Bootshop</p>
	</div><!-- Container End -->
	</div>
<!-- Placed at the end of the document so the pages load faster ============================================= -->
	<script src="<?php echo PATH_RESOURCE ?>assets/themes/js/jquery.js" type="text/javascript"></script>
	<script src="<?php echo PATH_RESOURCE ?>assets/themes/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="<?php echo PATH_RESOURCE ?>assets/themes/js/google-code-prettify/prettify.js"></script>
	
	<script src="<?php echo PATH_RESOURCE ?>assets/themes/js/bootshop.js"></script>
    <script src="<?php echo PATH_RESOURCE ?>assets/themes/js/jquery.lightbox-0.5.js"></script>

    <?php  fn_asset_js(); ?> 
<span id="themesBtn"></span>
</body>
</html>