<?php 
phpinfo();
 ?>